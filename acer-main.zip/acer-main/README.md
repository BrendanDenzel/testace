# Acer
A bookmarklet to disable extensions with an interface based on the chrome extension page

### Acer
For easy setup go the the website at https://brendandenzel.github.io/acer/

1. Open the website

2. Drag the Acer button to youyr bookmark bar

3. Then open click the button Acer

4. Once you open Acer click redirect

5. Then you click on the Acer bookmark in your bookmark on that new webstite you were redirected to

6. Then your free to turn off any extention you want
